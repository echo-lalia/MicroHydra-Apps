# mh_infrared
Infrared codes sender and reciever app for MicroHydra

This code can open .ir files, which you can get by exporting [Mi Remote Database](https://github.com/ysard/mi_remote_database) in Flipper format, and saving it in /sd/ir

Also you can scan signals using this code and external ir reciever module

UpyIrRx.py and UpyIrTx.py are stolen from [here](https://github.com/meloncookie/RemotePy)

Would be easier to code, if russians weren't bombing our power plants. [Help Ukraine](https://u24.gov.ua/)
