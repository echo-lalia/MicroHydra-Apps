try:
	from . import REPL
except ImportError:
	from apps.repl import REPL
